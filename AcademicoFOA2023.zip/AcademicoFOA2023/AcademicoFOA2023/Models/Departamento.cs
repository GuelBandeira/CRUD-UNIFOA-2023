﻿namespace AcademicoFOA2023.Models
{
    public class Departamento
    {
        public long? DepartamentoID { get; set; }
        public string Nome { get; set; }
    }
}
